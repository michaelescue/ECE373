/*
* Header for hw1.c.
*/

#ifdef _HW1_H
#define _HW1_H

#include <stdio.h>

#endif